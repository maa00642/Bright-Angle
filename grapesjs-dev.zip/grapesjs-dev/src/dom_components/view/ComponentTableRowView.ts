import ComponentView from './ComponentView';

export default class ComponentTableRowView extends ComponentView {}
