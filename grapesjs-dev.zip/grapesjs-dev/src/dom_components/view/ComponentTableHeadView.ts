import ComponentView from './ComponentView';

export default class ComponentTableHeadView extends ComponentView {}
