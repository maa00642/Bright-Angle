import ComponentView from './ComponentView';

export default class ComponentTableCellView extends ComponentView {}
