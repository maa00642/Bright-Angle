import ComponentLinkView from './ComponentLinkView';

export default class ComponentLabelView extends ComponentLinkView {}
