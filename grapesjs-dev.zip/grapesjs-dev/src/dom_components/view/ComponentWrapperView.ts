import ComponentView from './ComponentView';

export default class ComponentWrapperView extends ComponentView {
  tagName() {
    return 'div';
  }
}
