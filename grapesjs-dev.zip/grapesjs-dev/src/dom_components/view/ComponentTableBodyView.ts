import ComponentView from './ComponentView';

export default class ComponentTableBodyView extends ComponentView {}
