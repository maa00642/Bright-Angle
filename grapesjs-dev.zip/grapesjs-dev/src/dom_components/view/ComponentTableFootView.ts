import ComponentView from './ComponentView';

export default class ComponentTableFootView extends ComponentView {}
