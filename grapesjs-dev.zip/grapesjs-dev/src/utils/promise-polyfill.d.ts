declare module 'promise-polyfill' {
  const defType: PromiseConstructor;
  export default defType;
}
